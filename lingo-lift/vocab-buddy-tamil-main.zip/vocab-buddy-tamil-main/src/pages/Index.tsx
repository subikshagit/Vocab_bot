import VocabBot from '@/components/VocabBot';

const Index = () => {
  return <VocabBot />;
};

export default Index;
