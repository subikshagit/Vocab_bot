import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { BookOpen, Search, Lightbulb, Star } from 'lucide-react';
import vocabBotImage from '@/assets/vocabbot-mascot.png';

interface WordData {
  word: string;
  meaning: string;
  tamilMeaning: string;
  example: string;
  synonym: string;
  encouragement: string;
}

// Sample vocabulary data
const vocabularyData: { [key: string]: WordData } = {
  "happy": {
    word: "Happy",
    meaning: "Feeling or showing pleasure and joy",
    tamilMeaning: "மகிழ்ச்சியான (Makizhchiyāna)",
    example: "She felt happy when she received the good news.",
    synonym: "Joyful",
    encouragement: "You're doing great! Keep learning!"
  },
  "brave": {
    word: "Brave",
    meaning: "Having courage and not being afraid",
    tamilMeaning: "தைரியமான (Thairiyamāna)",
    example: "The brave firefighter saved the cat from the tree.",
    synonym: "Courageous",
    encouragement: "Wonderful word choice! Isn't that inspiring?"
  },
  "curious": {
    word: "Curious",
    meaning: "Wanting to know or learn something",
    tamilMeaning: "ஆர்வமுள்ள (Ārvamulla)",
    example: "The curious student asked many questions in class.",
    synonym: "Inquisitive",
    encouragement: "Perfect! Stay curious about learning!"
  },
  "gentle": {
    word: "Gentle",
    meaning: "Kind, soft, and calm in nature",
    tamilMeaning: "மென்மையான (Menmaiyāna)",
    example: "She spoke in a gentle voice to comfort the child.",
    synonym: "Tender",
    encouragement: "Great job! You're expanding your vocabulary beautifully!"
  },
  "wisdom": {
    word: "Wisdom",
    meaning: "Good judgment and knowledge gained from experience",
    tamilMeaning: "ஞானம் (Ñānam)",
    example: "The old man shared his wisdom with the young people.",
    synonym: "Knowledge",
    encouragement: "Excellent! Wisdom comes from learning new words like this!"
  }
};

const VocabBot = () => {
  const [inputWord, setInputWord] = useState('');
  const [currentWord, setCurrentWord] = useState<WordData | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  const handleWordSearch = () => {
    if (!inputWord.trim()) return;
    
    setIsSearching(true);
    
    // Simulate a brief loading time for better UX
    setTimeout(() => {
      const wordKey = inputWord.toLowerCase().trim();
      const wordData = vocabularyData[wordKey];
      
      if (wordData) {
        setCurrentWord(wordData);
      } else {
        // Fallback for unknown words
        setCurrentWord({
          word: inputWord.charAt(0).toUpperCase() + inputWord.slice(1),
          meaning: "I'm still learning this word! Try words like 'happy', 'brave', 'curious', 'gentle', or 'wisdom'.",
          tamilMeaning: "நான் இந்த வார்த்தையை கற்றுக்கொண்டிருக்கிறேன்!",
          example: "Keep exploring new words - you're doing amazing!",
          synonym: "Explorer",
          encouragement: "Don't worry! Learning is a journey. Try another word!"
        });
      }
      setIsSearching(false);
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleWordSearch();
    }
  };

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <img 
              src={vocabBotImage} 
              alt="VocabBot mascot" 
              className="w-24 h-24 rounded-full shadow-vocab"
            />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-2">
            VocabBot
          </h1>
          <p className="text-lg text-muted-foreground mb-6">
            Your friendly AI vocabulary tutor! Let's learn new words together! 🌟
          </p>
          
          {/* Search Section */}
          <div className="flex gap-2 max-w-md mx-auto">
            <Input
              placeholder="Type a word to learn..."
              value={inputWord}
              onChange={(e) => setInputWord(e.target.value)}
              onKeyPress={handleKeyPress}
              className="text-center border-2 border-vocab-primary/20 focus:border-vocab-primary"
            />
            <Button 
              onClick={handleWordSearch}
              className="bg-gradient-primary hover:opacity-90 px-6"
              disabled={isSearching}
            >
              {isSearching ? (
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
              ) : (
                <Search className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Word Display Section */}
        {currentWord && (
          <Card className="shadow-gentle border-vocab-primary/10">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-3xl font-bold text-vocab-primary flex items-center justify-center gap-2">
                <BookOpen className="w-8 h-8" />
                {currentWord.word}
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* English Meaning */}
              <div className="bg-gradient-to-r from-vocab-primary/5 to-vocab-info/5 p-4 rounded-lg">
                <div className="flex items-start gap-2">
                  <Badge variant="secondary" className="bg-vocab-primary text-white">
                    Meaning
                  </Badge>
                </div>
                <p className="text-foreground font-medium mt-2 text-lg">
                  {currentWord.meaning}
                </p>
              </div>

              {/* Tamil Meaning */}
              <div className="bg-gradient-to-r from-vocab-secondary/5 to-vocab-success/5 p-4 rounded-lg">
                <div className="flex items-start gap-2">
                  <Badge variant="secondary" className="bg-vocab-secondary text-white">
                    Tamil
                  </Badge>
                </div>
                <p className="text-foreground font-medium mt-2 text-lg">
                  {currentWord.tamilMeaning}
                </p>
              </div>

              <Separator />

              {/* Example Sentence */}
              <div className="bg-gradient-to-r from-vocab-accent/5 to-vocab-accent/10 p-4 rounded-lg">
                <div className="flex items-start gap-2">
                  <Badge variant="secondary" className="bg-vocab-accent text-white">
                    Example
                  </Badge>
                </div>
                <p className="text-foreground italic mt-2 text-lg">
                  "{currentWord.example}"
                </p>
              </div>

              {/* Synonym */}
              <div className="bg-gradient-to-r from-vocab-info/5 to-vocab-primary/5 p-4 rounded-lg">
                <div className="flex items-start gap-2">
                  <Badge variant="secondary" className="bg-vocab-info text-white">
                    Synonym
                  </Badge>
                </div>
                <p className="text-foreground font-medium mt-2 text-lg">
                  {currentWord.synonym}
                </p>
              </div>

              {/* Encouragement */}
              <div className="text-center bg-gradient-warm p-4 rounded-lg">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Star className="w-5 h-5 text-white" />
                  <Lightbulb className="w-5 h-5 text-white" />
                </div>
                <p className="text-white font-medium text-lg">
                  {currentWord.encouragement}
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Sample Words */}
        {!currentWord && (
          <Card className="mt-8 shadow-gentle">
            <CardHeader>
              <CardTitle className="text-center text-vocab-primary">
                Try these sample words!
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap justify-center gap-2">
                {Object.keys(vocabularyData).map((word) => (
                  <Button
                    key={word}
                    variant="outline"
                    className="border-vocab-primary/30 hover:bg-vocab-primary hover:text-white"
                    onClick={() => {
                      setInputWord(word);
                      setCurrentWord(vocabularyData[word]);
                    }}
                  >
                    {word}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default VocabBot;